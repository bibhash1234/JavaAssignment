package Assignment1;

public class OddNumberExample {

	public static void main(String[] args) {
		System.out.print("The Odd number from 1-50 is : ");
		for(int i=1; i<=50;i++)
		{
			if(i%2!=0)
			{
				System.out.print(i +" ");
			}
			
		}
		

	}

}
