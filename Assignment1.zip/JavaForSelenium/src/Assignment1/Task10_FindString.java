package Assignment1;

public class Task10_FindString {

	public static void main(String[] args) {
		String names[]= {"Java","JavaScript","Selenium","Python","Mukesh"};
		//System.out.println(names[2]);
		for(int i=0;i<5;i++)
		{
			if(names[i]=="Selenium")
			System.out.println(names[i]);
		}
	}

}
