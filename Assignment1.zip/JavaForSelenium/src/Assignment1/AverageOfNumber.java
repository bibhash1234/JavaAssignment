package Assignment1;

public class AverageOfNumber {
	
	public static void main(String[] args) {
		int num1=10; 
		int num2 = 111; 
		int num3 = 8989; 
		int num4 = 7876;
		double num5= 90.78;
		double Avg=(num1+num2+num3+num4+num5)/5;
       System.out.println("The Average of all the 5 number is :"+Avg);
	}

}
