package Assignment1;

public class Task8_StudentMarks {

	public static void main(String[] args) {
     int arr[] = {88,12,89,55,35};
     System.out.println("Total element in the array is "+arr.length);
     for(int num:arr)
     {
    	 if(num>80)
    	 {
    		 System.out.println("Scored above 80 :" +num );
    	 }
     }
	}
	
}
