package Assignment1;

public class AdditionOfNumber {
	
	public static void main(String[] args) {
		int num1=10; 
		int num2 = 111; 
		int num3 = 8989; 
		int num4 = 7876;
		float num5= 90.78f;
		int sum=(int) (num1 + num2+num3+num4+num5);
		float sum1=num1+num2+num3+num4+num5;
       System.out.println("The Summation of all the number is :"+sum);
       System.out.println("The Summation of all the number is :"+sum1);
	}

}
