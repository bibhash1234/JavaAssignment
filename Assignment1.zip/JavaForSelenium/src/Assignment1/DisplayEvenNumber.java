package Assignment1;

public class DisplayEvenNumber {

	public static void main(String[] args) {
		System.out.print("The Even number from 1-200 is : ");
		for(int i=1; i<=200;i++)
		{
			if(i%2==0)
			{
				System.out.print(i +" ");
			}
			
		}
		

	}

}
