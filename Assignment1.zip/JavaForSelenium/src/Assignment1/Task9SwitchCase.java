package Assignment1;

public class Task9SwitchCase {

	public static void main(String[] args) {
		int num[]= new int[5];
        num[0]=12;
        num[1]=34;
        num[2]=66;
        num[3]=85;
        num[4]=900;
        System.out.println(num[3]);
	}
	
}
