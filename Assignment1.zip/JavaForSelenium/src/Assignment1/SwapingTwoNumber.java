package Assignment1;

public class SwapingTwoNumber {

	public static void main(String[] args) {
		System.out.println("This program is for swapping of two number");
        int x=10;
        int y=15;
       System.out.println("Before Swapping:"); 
       System.out.println("The value of x is :"+x);
       System.out.println("The Value of Y is :"+y);
       int temp;
       temp=x;
       x=y;
       y=temp;
       System.out.println("After Swapping:");
       System.out.println("The value of x is :"+x);
       System.out.println("The Value of Y is :"+y);
	}

}
